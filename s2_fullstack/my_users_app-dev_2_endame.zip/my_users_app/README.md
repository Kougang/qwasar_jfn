# Welcome to My Users App
***

## Task
the aim is to create a user web application using the language ruby

## Description
i used sqlite 3 gem to create a model of the user app in a ruby file (my_user_model), it serves as an interface to create, find, get all, update and destroy user, it also include a tale with multiple attributes, firstname, last, age, email and password.
i also created a controller in the ruby file app.rb, the controller uses a user from my_user_model.rb and it returns json. i also created an index.erb file which serves as a template for the for the route.

## Installation
ruby gem is installed
sinatra is installed
gem bundle is installed

## Usage
to use this program, you will access it on port 8080.

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
